/**
 * Script de autenticação para o site institucional
 * Sistema de login separado do Portal do Piloto
 */

// Armazenamento de token na localStorage
const TOKEN_KEY = 'institucional_token';
const ADMIN_DATA_KEY = 'institucional_admin';

// Função para fazer login
async function login(email, password) {
  try {
    // Alterando para corresponder à rota sugerida no arquivo de ajustes
    const response = await fetch('/institucional/api/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ email, password: password }) // Mantendo compatibilidade com senha/password
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.message || 'Erro ao fazer login');
    }

    const data = await response.json();
    
    // Guardar token e dados do admin no localStorage
    localStorage.setItem(TOKEN_KEY, data.token);
    localStorage.setItem(ADMIN_DATA_KEY, JSON.stringify(data.admin));
    
    return data;
  } catch (error) {
    console.error('Erro de login:', error);
    throw error;
  }
}

// Função para verificar se o token é válido
async function verifyToken(token) {
  try {
    const response = await fetch('/institucional/api/verify-token', {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token}`
      }
    });

    if (!response.ok) {
      localStorage.removeItem(TOKEN_KEY);
      localStorage.removeItem(ADMIN_DATA_KEY);
      return false;
    }

    const data = await response.json();
    localStorage.setItem(ADMIN_DATA_KEY, JSON.stringify(data.admin));
    return true;
  } catch (error) {
    console.error('Erro ao verificar token:', error);
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(ADMIN_DATA_KEY);
    return false;
  }
}

// Função para verificar autenticação
async function isAuthenticated() {
  // Verificar se existe token institucional
  const token = localStorage.getItem(TOKEN_KEY);
  if (!token) return false;
  
  // Verificar também se existe dados do admin
  const adminData = localStorage.getItem(ADMIN_DATA_KEY);
  if (!adminData) return false;
  
  try {
    // Verificar se os dados do admin são JSON válido
    JSON.parse(adminData);
  } catch (e) {
    // Se não for JSON válido, limpar e retornar não autenticado
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(ADMIN_DATA_KEY);
    return false;
  }
  
  // Verificar a validade do token com o servidor
  return await verifyToken(token);
}

// Função para obter dados do admin
function getAdminData() {
  const adminJSON = localStorage.getItem(ADMIN_DATA_KEY);
  if (!adminJSON) return null;
  
  try {
    return JSON.parse(adminJSON);
  } catch (error) {
    console.error('Erro ao processar dados do admin:', error);
    return null;
  }
}

// Função para configurar cabeçalho de autorização para requisições
function getAuthHeader() {
  const token = localStorage.getItem(TOKEN_KEY);
  if (!token) return {};
  
  return {
    'Authorization': `Bearer ${token}`
  };
}

// Função para fazer logout
function logout() {
  // Limpar todos os itens de autenticação institucional
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(ADMIN_DATA_KEY);
  
  // Limpar possíveis tokens do Portal principal para evitar conflitos
  // Isso é importante para garantir que não haja interferência entre os sistemas
  localStorage.removeItem('authToken');
  localStorage.removeItem('userData');
  
  // Redirecionar para a página de login, usando replace para limpar o histórico
  // Usar protocolo completo para evitar interferência do React Router
  window.location.replace(window.location.origin + '/institucional/admin/login.html');
}

// Função para configurar o ambiente após login
function setupAdminEnvironment() {
  // Atualizar UI com nome do admin
  const adminData = getAdminData();
  if (adminData) {
    const adminNameElements = document.querySelectorAll('.admin-name');
    adminNameElements.forEach(element => {
      element.textContent = adminData.name;
    });
    
    // Configurar avatar se disponível
    const adminAvatarElements = document.querySelectorAll('.admin-avatar');
    adminAvatarElements.forEach(element => {
      if (adminData.avatar) {
        element.src = adminData.avatar;
      } else {
        element.src = '/institucional/public/images/default-avatar.png';
      }
    });
  }
  
  // Configurar botão de logout
  const logoutButtons = document.querySelectorAll('.admin-logout');
  logoutButtons.forEach(button => {
    button.addEventListener('click', function(e) {
      e.preventDefault();
      logout();
    });
  });
}

// Função para proteger rotas administrativas
async function protectAdminRoute() {
  const isAuth = await isAuthenticated();
  if (!isAuth) {
    // Usa window.location.replace para evitar problemas com histórico do navegador
    // Usar protocolo completo para evitar interferência do React Router
    window.location.replace(window.location.origin + '/institucional/admin/login.html');
    return false;
  }
  
  setupAdminEnvironment();
  return true;
}

// Função para redirecionar usuários autenticados (usado na página de login)
async function redirectIfAuthenticated() {
  const isAuth = await isAuthenticated();
  if (isAuth) {
    // Usa window.location.replace para evitar problemas com histórico do navegador
    // Usar protocolo completo para evitar interferência do React Router
    window.location.replace(window.location.origin + '/institucional/admin/index.html');
    return true;
  }
  return false;
}

// API para fazer requisições autenticadas
async function authFetch(url, options = {}) {
  const token = localStorage.getItem(TOKEN_KEY);
  if (!token) {
    throw new Error('Não autenticado');
  }
  
  const headers = {
    ...options.headers,
    'Authorization': `Bearer ${token}`
  };
  
  const response = await fetch(url, {
    ...options,
    headers
  });
  
  if (response.status === 401) {
    logout();
    throw new Error('Sessão expirada');
  }
  
  return response;
}